# 이름은 셸에서 사용하는 ASCII 파일 이름, Java 클래스/함수는 한국어다.
APP_NAMES := hello udp netcheck stress javac java
APP_SOURCE_javac := 사용자/자바/자바도구.java 사용자/자바/자바컴파일러.java
APP_ENTRY_javac := 자바컴파일러.시작
APP_SOURCE_java := 사용자/자바/자바도구.java 사용자/자바/자바가상기계.java
APP_ENTRY_java := 자바가상기계.시작
APP_SOURCE_hello := 사용자/예제/인사.java
APP_ENTRY_hello := 인사.시작
APP_SOURCE_udp := 사용자/예제/자료통신.java
APP_ENTRY_udp := 자료통신.시작
APP_SOURCE_netcheck := 사용자/예제/통신시험.java
APP_ENTRY_netcheck := 통신시험.시작
APP_SOURCE_stress := 사용자/예제/통신반복.java
APP_ENTRY_stress := 통신반복.시작
