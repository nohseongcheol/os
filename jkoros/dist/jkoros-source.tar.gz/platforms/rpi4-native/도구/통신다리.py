"""Layer-2/SLIP bridge. TCP, UDP and FTP are processed by the guest, not Python.

QEMU's user network supplies NAT/host forwarding. raspi4b has no emulated GENET,
so a second UART carries IPv4 packets to the guest's lwIP stack.
"""
import select
import socket
import struct
import threading
import time
import ipaddress

기계주소 = bytes.fromhex('525400123456')
관문기계주소 = bytes.fromhex('52550a000202')
인터넷주소값 = bytes((10, 0, 2, 15))


class 통신다리:
    def __init__(자신, 파일전송접속번호=2121, 전달규칙들=(), 포착여부=False, 게스트주소='10.0.2.15', 호스트주소='127.0.0.1'):
        if not 1024 <= 파일전송접속번호 <= 65535 or 50000 <= 파일전송접속번호 <= 50007:
            raise ValueError('FTP host port must be 1024..65535 excluding 50000..50007')
        자신.파일전송접속번호 = 파일전송접속번호
        주소=ipaddress.IPv4Address(게스트주소)
        if 주소 not in ipaddress.IPv4Network('10.0.2.0/24') or 주소.packed[-1] in (0,2,3,255):
            raise ValueError('Guest forward address must be 10.0.2.1..254 excluding 2 and 3')
        자신.게스트주소=str(주소); 자신.현재주소=주소.packed
        주소=ipaddress.IPv4Address(호스트주소)
        if 주소.is_multicast or str(주소)=='255.255.255.255':raise ValueError('Network forwarding host must be a unicast IPv4 address or 0.0.0.0')
        자신.호스트주소=str(주소)
        자신.포착여부 = 포착여부; 자신.추적기록 = []
        자신.전달규칙들 = []
        사용중주소 = {('tcp', 파일전송접속번호)} | {('tcp', 자료위치) for 자료위치 in range(50000,50008)}
        for 규칙 in 전달규칙들:
            경로부분 = 규칙.split(':')
            if len(경로부분) != 3 or 경로부분[0] not in ('tcp', 'udp'):
                raise ValueError('forward must be tcp:HOST_PORT:GUEST_PORT or udp:HOST_PORT:GUEST_PORT')
            통신규약, 호스트, 커널실행 = 경로부분[0], int(경로부분[1]), int(경로부분[2])
            if not 1024 <= 호스트 <= 65535 or not 1 <= 커널실행 <= 65535 or (통신규약, 호스트) in 사용중주소:
                raise ValueError('invalid or duplicate forward: ' + 규칙)
            사용중주소.add((통신규약, 호스트)); 자신.전달규칙들.append((통신규약, 호스트, 커널실행))
        자신.수신창구들 = []
        for _ in range(2):
            서버 = socket.socket()
            서버.bind(('127.0.0.1', 0)); 서버.listen(1); 서버.setblocking(False)
            자신.수신창구들.append(서버)
        자신.접속자들 = [None, None]
        자신.대기중 = [bytearray(), bytearray()]
        자신.이더넷자료 = bytearray(); 자신.직렬전문 = bytearray(); 자신.탈출됨 = 자신.잘못됨 = False
        자신.멈춤사건 = threading.Event(); 자신.오류 = None
        자신.커널수신틀수 = 자신.커널발신틀수 = 0
        자신.작업가닥 = threading.Thread(target=자신.순환, daemon=True)
        자신.작업가닥.start()

    def 전달인수(자신):
        직렬접속번호, 이더넷접속번호 = [문자열값.getsockname()[1] for 문자열값 in 자신.수신창구들]
        전달규칙 = 'user,id=wan,net=10.0.2.0/24,hostfwd=tcp:127.0.0.1:{}-{}:21'.format(자신.파일전송접속번호, 자신.게스트주소)
        for 접속번호 in range(50000, 50008):
            전달규칙 += ',hostfwd=tcp:127.0.0.1:{0}-{1}:{0}'.format(접속번호, 자신.게스트주소)
        for 통신규약, 호스트, 커널실행 in 자신.전달규칙들:
            전달규칙 += ',hostfwd={}:127.0.0.1:{}-{}:{}'.format(통신규약, 호스트, 자신.게스트주소, 커널실행)
        전달규칙=전달규칙.replace('127.0.0.1:',자신.호스트주소+':')
        return ['-chardev', 'socket,id=slip,host=127.0.0.1,port={}'.format(직렬접속번호),
                '-serial', 'chardev:slip', '-netdev', 전달규칙,
                '-netdev', 'socket,id=wire,connect=127.0.0.1:{}'.format(이더넷접속번호),
                '-netdev', 'hubport,id=wanhub,hubid=0,netdev=wan',
                '-netdev', 'hubport,id=wirehub,hubid=0,netdev=wire']

    def 실행틀(자신, 꾸러미자료):
        자신.대기중[1] += struct.pack('!I', len(꾸러미자료)) + 꾸러미자료

    def 전문추적(자신, 방향, 꾸러미자료):
        if not 자신.포착여부 or len(꾸러미자료)<20: return
        변위=(꾸러미자료[0]&15)*4
        항목={'time':time.monotonic(),'direction':방향,'bytes':len(꾸러미자료),'protocol':꾸러미자료[9]}
        if 꾸러미자료[9]==6 and len(꾸러미자료)>=변위+20:
            원본자료,목적자료주소,순서번호,확인번호,설정비트,창=struct.unpack_from('!HHIIHH',꾸러미자료,변위)
            항목.update(source=원본자료,destination=목적자료주소,seq=순서번호,ack=확인번호,flags=설정비트&255,window=창,
                        payload=len(꾸러미자료)-변위-((꾸러미자료[변위+12]>>4)*4))
        자신.추적기록.append(항목)
        if len(자신.추적기록)>2048: del 자신.추적기록[:1024]

    def 직렬전문입력(자신, 자료):
        for 문자값 in 자료:
            if 문자값 == 192:
                if 자신.직렬전문 and not 자신.잘못됨 and not 자신.탈출됨:
                    # Learn the actual SLIP source after guest ipconfig changes.
                    # The bridge still only answers ARP for one current address.
                    if len(자신.직렬전문)>=20 and 자신.직렬전문[0]>>4==4:
                        주소=bytes(자신.직렬전문[12:16])
                        if 주소[:3]==b'\x0a\x00\x02' and 주소[3] not in (0,2,3,255): 자신.현재주소=주소
                    자신.전문추적('from_guest',자신.직렬전문)
                    자신.실행틀(관문기계주소 + 기계주소 + b'\x08\x00' + 자신.직렬전문)
                    자신.커널발신틀수 += 1
                자신.직렬전문.clear(); 자신.탈출됨 = 자신.잘못됨 = False
            elif 문자값 == 219 and not 자신.탈출됨:
                자신.탈출됨 = True
            else:
                if 자신.탈출됨:
                    if 문자값 not in (220, 221): 자신.잘못됨 = True
                    문자값 = 192 if 문자값 == 220 else 219
                    자신.탈출됨 = False
                if len(자신.직렬전문) < 1600: 자신.직렬전문.append(문자값)
                else: 자신.잘못됨 = True

    def 이더넷입력(자신, 자료):
        자신.이더넷자료 += 자료
        while len(자신.이더넷자료) >= 4:
            개수 = struct.unpack_from('!I', 자신.이더넷자료)[0]
            if 개수 > 65536: raise ValueError('oversized QEMU Ethernet frame')
            if len(자신.이더넷자료) < 개수 + 4: return
            실행틀 = bytes(자신.이더넷자료[4:4+개수]); del 자신.이더넷자료[:4+개수]
            if len(실행틀) < 14: continue
            if 실행틀[12:14] == b'\x08\x06' and len(실행틀) >= 42:
                주소찾기전문 = 실행틀[14:42]
                if 주소찾기전문[:8] == b'\x00\x01\x08\x00\x06\x04\x00\x01' and 주소찾기전문[24:28] == 자신.현재주소:
                    응답자료 = 주소찾기전문[:6] + b'\x00\x02' + 기계주소 + 자신.현재주소 + 주소찾기전문[8:18]
                    자신.실행틀(실행틀[6:12] + 기계주소 + b'\x08\x06' + 응답자료)
            elif 실행틀[12:14] == b'\x08\x00':
                꾸러미자료 = 실행틀[14:]
                자신.전문추적('to_guest',꾸러미자료)
                자신.대기중[0] += b'\xc0' + 꾸러미자료.replace(b'\xdb', b'\xdb\xdd').replace(b'\xc0', b'\xdb\xdc') + b'\xc0'
                자신.커널수신틀수 += 1

    def 순환(자신):
        try:
            while not 자신.멈춤사건.is_set():
                읽기대상들 = [문자열값 for 순번, 문자열값 in enumerate(자신.수신창구들) if 자신.접속자들[순번] is None]
                읽기대상들 += [문자열값 for 문자열값 in 자신.접속자들 if 문자열값 is not None]
                쓰기대상들 = [문자열값 for 순번, 문자열값 in enumerate(자신.접속자들) if 문자열값 is not None and 자신.대기중[순번]]
                읽을수있음, 쓸수있음, _ = select.select(읽기대상들, 쓰기대상들, [], .05)
                for 문자열값 in 읽을수있음:
                    if 문자열값 in 자신.수신창구들:
                        순번 = 자신.수신창구들.index(문자열값); 자신.접속자들[순번], _ = 문자열값.accept(); 자신.접속자들[순번].setblocking(False)
                    else:
                        순번 = 자신.접속자들.index(문자열값); 자료 = 문자열값.recv(16384)
                        if not 자료: return
                        (자신.직렬전문입력 if 순번 == 0 else 자신.이더넷입력)(자료)
                for 문자열값 in 쓸수있음:
                    순번 = 자신.접속자들.index(문자열값)
                    try: 개수 = 문자열값.send(자신.대기중[순번])
                    except BlockingIOError: continue
                    del 자신.대기중[순번][:개수]
                if any(len(둘째값) > 1024 * 1024 for 둘째값 in 자신.대기중):
                    raise RuntimeError('SLIP bridge queue exhausted')
        except Exception as 보조항목:
            if not 자신.멈춤사건.is_set(): 자신.오류 = str(보조항목)

    def 닫기(자신):
        자신.멈춤사건.set(); 자신.작업가닥.join(timeout=2)
        for 문자열값 in 자신.수신창구들 + 자신.접속자들:
            if 문자열값 is not None: 문자열값.close()

    def __enter__(자신): return 자신
    def __exit__(자신, *인수배열): 자신.닫기()
