#ifndef 자체꾸러미머리
#define 자체꾸러미머리
#include <stddef.h>
int 꾸러미열기(const char *파일이름);
int 꾸러미읽기(const char *이름, unsigned char *결과자료, unsigned 수용량);
const char *꾸러미진입클래스(void);
#endif
