// Copyright 2020. (노성철, nsch78@nate.com, nsch@naver.com) All right reserved
package 한국어.자체;
/** 단추 등의 동작 알림을 받아 처리하는 역할. */
public interface 동작받이 {
    void 동작받기(동작알림 알림);
}
